

var test1 = {
		partners:"mint|nadi",
		countries:"us|br",
		cookie : "cookiepp",
		config:[{
				idleTimeInSeconds:15,
				breakTimeInHours:8,
				rowid:"12231332423",
			} ,
			{
				idleTimeInSeconds:10000000000000000,
				breakTimeInHours:8,
				rowid:"12231332424",
			} ]	
	} ;


var test2 = {
		partners:"mrlmpu|default|jaxz|dpknlg|dpknlgob|dpknlgpe|dpknlgpf|edgnc|airi|airiob|airipe|airipf|dpmnt|apsnob|apsnpf|mpoo|dpbndlr|cnet|cnetindia|ctmamf|duit|cool|mium|dpplt|acce|dius|elex|epom|epomob|laro|fisopf|flaw|gtcoob|guga|malipf|inff|syme|iris|dpbrn|dptgl|dpw7th|facemoods|iron|ironmc|ironna|ironnapb|ironpb|ironpf|ironpm|ironppi|ironppipb|ironppipf|omel|oooironppi|pfna|vn|kxso|liby|marm|trsi|mindob|dock|dockes|dockob|dockpe|onek|cand|outb|toyf|toyfob|pals|omelp|pcdeal|pcdealb|pcdealply|vn|vito|rbms|rbmsob|sft3|xtrm|alimob|toni|soli|moto|somo|somopf|dgzlob|dgzlpf|dpaln|dpalnob|dpalnpf|dpalnwb|ultrob|vbee|vita|rokt|wbpk|wddtob|lpws",
		countries:"br|de|ru|it|es|fr|nl|ir|mx|jp|gb|dk|in|ar|ca|se|au|at|tr|ro|cn",
		cookie : "cookiepp",
		config:[
			{
				idleTimeInSeconds:15,
				breakTimeInHours:3.5,
				rowid:"12231332425",
			} ]	
	} ;


var testspp = [test2];
//var testspp = [test1];
//var testspp = [];

